# RIGEL Brief AI

RIGEL Brief AI, proje fikirlerini düzenli bir brief haline getiren Streamlit tabanlı MVP uygulamasıdır.

## v7 polish düzeltmeleri

- Gereksiz büyük başlık blokları ve boş görünen kartlar küçültüldü.
- Sonuç kartları artık tek parça HTML olarak çiziliyor; boş büyük kutu hissi kaldırıldı.
- Textarea köşelerindeki siyah iz/resize sorunu giderildi.
- Textarea daha kompakt ve temiz hale getirildi.
- Step wizard korunarak kullanıcı akışı sadeleştirildi.
- Canva benzeri modern tema korundu.
- RDS wordmark ve ortadaki Rigel Digital Systems yazısı korundu.
- PDF Türkçe karakter desteği korundu.

## Kurulum

```bash
cd rigel_brief_ai
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
streamlit run app.py
```

Windows PowerShell:

```powershell
cd rigel_brief_ai
python -m venv .venv
.venv\\Scripts\\Activate.ps1
pip install -r requirements.txt
streamlit run app.py
```
